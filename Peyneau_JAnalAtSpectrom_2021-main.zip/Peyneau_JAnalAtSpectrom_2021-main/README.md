# Peyneau_JAnalAtSpectrom_2021

Computer programs used for the article *Number of spikes in single particle ICP-MS time scans: from the very dilute to the highly concentrated range*.
